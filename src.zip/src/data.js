﻿export const bikesData = [
  // 10 Normal Bikes
  { id: 1, name: "Ninja Sport 650", brand: "Kawasaki", category: "Motorcycles", type: "Normal", price: "&#8377;6,50,000", rating: 4.8, img: "https://images.unsplash.com/photo-1558981403-c5f9899a28bc?q=80&w=600" },
  { id: 2, name: "CBR Fireblade", brand: "Honda", category: "Motorcycles", type: "Normal", price: "&#8377;19,00,000", rating: 4.9, img: "/cbr_fireblade.jpg" },
  { id: 3, name: "Street Glide", brand: "Royal Enfield", category: "Cruiser", type: "Normal", price: "&#8377;24,50,000", rating: 4.7, img: "https://images.unsplash.com/photo-1558981806-ec527fa84c39?q=80&w=600" },
  { id: 4, name: "R15 V4", brand: "Yamaha", category: "Motorcycles", type: "Normal", price: "&#8377;1,85,000", rating: 4.6, img: "https://images.unsplash.com/photo-1622185135505-2d795003994a?q=80&w=600" },
  { id: 5, name: "Activa 6G", brand: "Honda", category: "Scooty", type: "Normal", price: "&#8377;80,000", rating: 4.5, img: "/activa.jpg" },
  { id: 6, name: "Jupiter 125", brand: "TVS", category: "Scooty", type: "Normal", price: "&#8377;85,000", rating: 4.4, img: "/jupiter.jpg" },
  { id: 7, name: "Pulsar NS200", brand: "Bajaj", category: "Motorcycles", type: "Normal", price: "&#8377;1,45,000", rating: 4.5, img: "/pulsar.jpg" },
  { id: 8, name: "Duke 390", brand: "KTM", category: "Motorcycles", type: "Normal", price: "&#8377;3,15,000", rating: 4.7, img: "/duke.jpg" },
  { id: 9, name: "Bullet 350", brand: "Royal Enfield", category: "Motorcycles", type: "Normal", price: "&#8377;1,75,000", rating: 4.6, img: "/bullet.jpg" },
  { id: 10, name: "FZ-S", brand: "Yamaha", category: "Motorcycles", type: "Normal", price: "&#8377;1,25,000", rating: 4.3, img: "/fzs.jpg" },
  
  // 10 EV/Robotic Bikes
  { id: 11, name: "Tesla CyberMoto", brand: "Tesla", category: "Motorcycles", type: "EV Bikes", price: "&#8377;8,99,000", rating: 4.9, img: "/ev_bike_1.png", range: "600 km", chargingTime: "1 Hour", smartFeatures: "L5 Autonomy, Voxa Built-in" },
  { id: 12, name: "Ather 450X", brand: "Ather", category: "Scooty", type: "EV Bikes", price: "&#8377;1,45,000", rating: 4.8, img: "/ev_bike_2.png", range: "150 km", chargingTime: "4 Hours", smartFeatures: "Maps Nav, Ride Stats" },
  { id: 13, name: "Ola S1 Pro", img: "/ev_bike_4.png", brand: "Ola", category: "Scooty", type: "EV Bikes", price: "&#8377;1,35,000", rating: 4.7, range: "181 km", chargingTime: "3.5 Hours", smartFeatures: "Party Mode, Voice Commands" },
  { id: 14, name: "Ultraviolette F77", brand: "Ultraviolette", category: "Motorcycles", type: "EV Bikes", price: "&#8377;3,95,000", rating: 4.8, img: "/ev_bike_3.png", range: "307 km", chargingTime: "2 Hours", smartFeatures: "Aviation Dynamics, 3Ride Modes" },
  { id: 15, name: "Revolt RV400", img: "/ev_bike_5.png",  brand: "Revolt", category: "Motorcycles", type: "EV Bikes", price: "&#8377;1,30,000", rating: 4.5, range: "150 km", chargingTime: "4.5 Hours", smartFeatures: "Geo-Fencing, App Connect" },
  { id: 16, name: "Zero SR/S", img: "/ev_bike_6.png",  brand: "Zero", category: "Motorcycles", type: "EV Bikes", price: "&#8377;12,00,000", rating: 4.7, range: "365 km", chargingTime: "1.5 Hours", smartFeatures: "Cypher III+ OS" },
  { id: 17, name: "TVS iQube", img: "/ev_bike_7.png",  brand: "TVS", category: "Scooty", type: "EV Bikes", price: "&#8377;1,20,000", rating: 4.6, range: "140 km", chargingTime: "5 Hours", smartFeatures: "Alexa Integration" },
  { id: 18, name: "Bajaj Chetak EV", img: "/ev_bike_8.png",  brand: "Bajaj", category: "Scooty", type: "EV Bikes", price: "&#8377;1,25,000", rating: 4.5, range: "110 km", chargingTime: "4 Hours", smartFeatures: "Steel Body, Reverse Mode" },
  { id: 19, name: "Hero Vida V1", img: "/ev_bike_9.png",  brand: "Hero", category: "Scooty", type: "EV Bikes", price: "&#8377;1,40,000", rating: 4.4, range: "165 km", chargingTime: "3.5 Hours", smartFeatures: "Removable Battery" },
  { id: 20, name: "LiveWire", img: "/ev_bike_10.png",  brand: "Harley", category: "Motorcycles", type: "EV Bikes", price: "&#8377;18,50,000", rating: 4.8, range: "235 km", chargingTime: "1 Hour", smartFeatures: "H-D Connect" }
,
  // 10 Robotic Bikes
  { id: 21, name: "RoboX AI", brand: "X-Corp", category: "motorcycle", type: "robotic", price: "&#8377;14,99,000", rating: 4.9, img: "/robo_bike_1.png" },
  { id: 22, name: "Neural Glider", brand: "Neural", category: "motorcycle", type: "robotic", price: "&#8377;21,50,000", rating: 4.8, img: "/robo_bike_2.png" },
  { id: 23, name: "Synapse V1", brand: "Synapse", category: "motorcycle", type: "robotic", price: "&#8377;9,99,000", rating: 4.7, img: "/synapse.jpg" },
  { id: 24, name: "CyberCruiser", brand: "Tesla", category: "cruiser", type: "robotic", price: "&#8377;12,45,000", rating: 4.8, img: "/cybercruiser.jpg" },
  { id: 25, name: "AutoMoto 9", brand: "AutoMoto", category: "motorcycle", type: "robotic", price: "&#8377;16,00,000", rating: 4.9, img: "/automoto9.jpg" },
  { id: 26, name: "Neon Strider", brand: "Neon", category: "motorcycle", type: "robotic", price: "&#8377;8,75,000", rating: 4.6, img: "/neonstrider.jpg" },
  { id: 27, name: "Quantum Sprint", brand: "Quantum", category: "scooty", type: "robotic", price: "&#8377;3,20,000", rating: 4.5, img: "/quantum.jpg" },
  { id: 28, name: "Apex DroneBike", brand: "Apex", category: "motorcycle", type: "robotic", price: "&#8377;25,99,000", rating: 5.0, img: "/robo_bike_3.png" },
  { id: 29, name: "Void Runner", brand: "Void", category: "cruiser", type: "robotic", price: "&#8377;19,50,000", rating: 4.8, img: "/voidrunner.jpg" },
  { id: 30, name: "Hyperion X", brand: "Hyperion", category: "motorcycle", type: "robotic", price: "&#8377;29,00,000", rating: 4.9, img: "https://images.unsplash.com/photo-1568454537842-d933259bb258?q=80&w=600" }
];