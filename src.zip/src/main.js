﻿
import './style.css';
import { bikesData } from './data.js';

document.addEventListener('DOMContentLoaded', () => {

    // Global: Initialize Intersection Observer for Scroll Reveals
    const observerOptions = { root: null, rootMargin: '0px', threshold: 0.15 };
    const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if(entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                obs.unobserve(entry.target);
            }
        });
    }, observerOptions);

    const observeReveals = () => {
        document.querySelectorAll('.reveal-on-scroll').forEach(el => observer.observe(el));
    };

    // 1. Auth Toggle (Index Page)
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    if(document.getElementById('show-signup')){
        document.getElementById('show-signup').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('login-section').style.display = 'none';
            document.getElementById('signup-section').style.display = 'block';
        });
        document.getElementById('show-login').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('signup-section').style.display = 'none';
            document.getElementById('login-section').style.display = 'block';
        });
    }
    if(loginForm) loginForm.addEventListener('submit', (e) => { e.preventDefault(); window.location.href = '/home.html'; });
    if(signupForm) signupForm.addEventListener('submit', (e) => { e.preventDefault(); window.location.href = '/home.html'; });

    // 2. Shared Navbar Setup
    const navContainer = document.getElementById('navbar-container');
    if (navContainer) {
        navContainer.innerHTML = `
            <nav class="navbar">
      <a href="/home.html" class="nav-brand">Robo<span>Ride</span></a>
      <ul class="nav-links" id="nav-links">
          <li><a href="/home.html">Home</a></li>
          <li><a href="/products.html">Products</a></li>
          <li><a href="/normal-bikes.html">Normal Bikes</a></li>
          <li><a href="/ev-bikes.html">EV Bikes</a></li>
          <li><a href="/robotics.html">Robotics Bikes</a></li>
          <li><a href="/cart.html">Cart</a></li>
          <li><a href="/chatbot.html">Chatbot</a></li>
          <li><a href="/about.html">About Us</a></li>
          <li><a href="/help.html">Help</a></li>
      </ul>
      <div class="hamburger" id="hamburger">
          <span></span><span></span><span></span>
      </div>
  </nav>
        `;
        const newNavbar = navContainer.querySelector('.navbar');
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) newNavbar.classList.add('scrolled');
            else newNavbar.classList.remove('scrolled');
        });
        // Set scrolled instantly if not home
        if(window.location.pathname.indexOf('home.html') === -1) {
            newNavbar.classList.add('scrolled');
            newNavbar.style.background = 'rgba(5,5,5,0.95)';
        }
    }

    
    // Meet Voxa Popup logic
    if (window.location.pathname.indexOf('home.html') !== -1) {
        if (!sessionStorage.getItem('voxaWelcomed')) {
            sessionStorage.setItem('voxaWelcomed', 'true');
            const welcomeModal = document.createElement('div');
            welcomeModal.style.position = 'fixed';
            welcomeModal.style.inset = '0';
            welcomeModal.style.background = 'rgba(5,5,5,0.9)';
            welcomeModal.style.zIndex = '99999';
            welcomeModal.style.display = 'flex';
            welcomeModal.style.alignItems = 'center';
            welcomeModal.style.justifyContent = 'center';
            welcomeModal.style.backdropFilter = 'blur(10px)';
            welcomeModal.innerHTML = `
                <div class="glass-panel" style="padding: 4rem; text-align: center; max-width: 600px; border-color: var(--primary); box-shadow: 0 0 50px rgba(0,229,255,0.4);">
                    <h2 class="text-gradient">Meet Voxa</h2>
                    <p class="text-muted" style="margin-top: 1rem; font-size: 1.2rem;">Chat with Voxa for any queries, fleet recommendations, and support info! You can find her in the bottom right corner.</p>
                    <button class="btn btn-primary" style="margin-top: 3rem;" id="close-modal-btn">Engage Systems</button>
                </div>
            `;
            document.body.appendChild(welcomeModal);
            document.getElementById('close-modal-btn').addEventListener('click', () => {
                welcomeModal.remove();
            });
        }
    }

    // Home Page Render & Filter Logic
    const gridContainer = document.getElementById('product-grid-container');
    const searchInput = document.getElementById('search-input');
    
    if (gridContainer) {
        let currentFilter = 'All';
        let searchQuery = '';

        const renderFilteredCards = () => {
            const cards = gridContainer.querySelectorAll('.product-card');
            cards.forEach(card => {
                const type = card.getAttribute('data-type');
                const cat = card.getAttribute('data-cat');
                const rating = parseFloat(card.getAttribute('data-rating'));
                const priceStr = card.getAttribute('data-price').replace(/[^0-9]/g, '');
                const priceNum = parseInt(priceStr);
                const title = card.querySelector('h3').innerText.toLowerCase();
                const brand = card.getAttribute('data-brand').toLowerCase();

                let match = false;
                if(currentFilter === 'All') match = true;
                else if(currentFilter === 'Normal Bikes' && type === 'Normal') match = true;
                else if(currentFilter === 'EV Bikes' && type === 'EV Bikes') match = true;
                else if(currentFilter === 'Motorcycles' && cat === 'Motorcycles') match = true;
                else if(currentFilter === 'Scooty' && cat === 'Scooty') match = true;
                else if(currentFilter === 'High Rating' && rating >= 4.5) match = true;
                else if(currentFilter === 'Top Brands' && (brand==='tesla'||brand==='ather'||brand==='honda'||brand==='kawasaki')) match = true;

                // Evaluate Search Query
                if (searchQuery && !title.includes(searchQuery) && !brand.includes(searchQuery)) {
                    match = false;
                }

                if(match){
                    card.style.display = 'flex';
                    card.style.animation = 'none';
                    card.offsetHeight;
                    card.style.animation = null;
                    card.classList.add('animate-fade-in');
                } else {
                    card.style.display = 'none';
                    card.classList.remove('animate-fade-in');
                }
            });
        };

        // Render all initially instantly
        gridContainer.innerHTML = '';
        bikesData.forEach((bike, index) => {
            const card = document.createElement('div');
            card.className = 'product-card reveal-on-scroll ' + bike.category.toLowerCase() + ' ' + bike.type.toLowerCase();
            card.style.transitionDelay = `${(index % 5) * 0.1}s`;
            card.setAttribute('data-type', bike.type);
            card.setAttribute('data-cat', bike.category);
            card.setAttribute('data-rating', bike.rating);
            card.setAttribute('data-price', bike.price);
            card.setAttribute('data-brand', bike.brand);
            card.innerHTML = `
                
                ${bike.type === 'EV Bikes' ? '<div class="badge-tech">EV SMART</div>' : ''}
                <div class="product-img-wrapper" onclick="window.location.href='/product-detail.html?id=' + bike.id">
                    <div class="product-badge">&#9733; ${bike.rating}</div>
                    <div class="product-img" style="background-image: url('${bike.img}');" title="${bike.brand} ${bike.name}"></div>
                </div>
                <div class="product-info">
                    <p class="text-muted" style="margin-bottom: 0.25rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; font-size:0.85rem;">${bike.brand} â€¢ ${bike.category}</p>
                    <h3>${bike.name}</h3>
                    
                    <p class="text-muted" style="margin-top: 0.5rem; font-size: 0.9rem;">Modern AI-assisted architecture.</p>
                    ${bike.type === 'EV Bikes' ? `
                      <div class="ev-stats">
                         <div class="ev-stat">Range: <span>${bike.range}</span></div>
                         <div class="ev-stat">Charge: <span>${bike.chargingTime}</span></div>
                      </div>
                    ` : ''}

                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div class="product-price">${bike.price}</div>
                        <button class="btn btn-outline" style="padding:0.5rem 1rem; border:1px solid rgba(255,255,255,0.2); color:#fff; border-radius:50%;" onclick="window.location.href='/product-detail.html?id=' + bike.id">...</button>
                    </div>
                </div>
            `;
            gridContainer.appendChild(card);
        });

        // Filter Click Logic
        const btns = document.querySelectorAll('.category-btn');
        btns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                btns.forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                currentFilter = e.target.getAttribute('data-filter');
                renderFilteredCards();
            });
        });

        // Search Input Logic
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                searchQuery = e.target.value.toLowerCase().trim();
                renderFilteredCards();
            });
        }
    }

    // 4. Inject Global Voxa Widget
    // We only inject if not on index.html
    if(window.location.pathname.indexOf('index.html') === -1 && window.location.pathname !== '/') {
        const voxaWidget = document.createElement('div');
        voxaWidget.className = 'voxa-widget';
        voxaWidget.innerHTML = `
            <div class="voxa-window" id="voxa-window">
               <div class="voxa-header">
                  <span></span>
                  <h3>Voxa AI Engine</h3>
               </div>
               <div class="voxa-body" id="voxa-body">
                  <div class="msg bot">Terminal Connected. I am Voxa. How can I assist your mobility selection today?</div>
               </div>
               <div class="voxa-input-area">
                  <input type="text" id="voxa-input" placeholder="Type a command...">
                  <button id="voxa-send">âœ“</button>
               </div>
            </div>
            <div class="voxa-button" id="voxa-toggle-btn">
               <svg viewBox="0 0 24 24"><path d="M12 2C6.477 2 2 6.477 2 12C2 17.522 6.477 22 12 22C17.522 22 22 17.522 22 12C22 6.477 17.522 2 12 2ZM12 18C8.686 18 6 15.314 6 12C6 8.686 8.686 6 12 6C15.314 6 18 8.686 18 12C18 15.314 15.314 18 12 18ZM12 8C9.79 8 8 9.79 8 12C8 14.21 9.79 16 12 16C14.21 16 16 14.21 16 12C16 9.79 14.21 8 12 8Z"/></svg>
            </div>
        `;
        document.body.appendChild(voxaWidget);

        const voxaBtn = document.getElementById('voxa-toggle-btn');
        const voxaWin = document.getElementById('voxa-window');
        const voxaBody = document.getElementById('voxa-body');
        const voxaInput = document.getElementById('voxa-input');
        const voxaSend = document.getElementById('voxa-send');

        voxaBtn.addEventListener('click', () => { voxaWin.classList.toggle('active'); });

        const appendMsg = (text, isUser) => {
            const div = document.createElement('div');
            div.className = 'msg ' + (isUser ? 'user' : 'bot');
            div.innerHTML = text;
            voxaBody.appendChild(div);
            voxaBody.scrollTop = voxaBody.scrollHeight;
        };

        const generateBotTyping = () => {
            const div = document.createElement('div');
            div.className = 'msg bot typing';
            div.innerHTML = '<div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div>';
            voxaBody.appendChild(div);
            voxaBody.scrollTop = voxaBody.scrollHeight;
            return div;
        };

        const handleChat = () => {
            const val = voxaInput.value.trim();
            if(!val) return;
            appendMsg(val, true);
            voxaInput.value = '';
            
            const typingEl = generateBotTyping();
            
            setTimeout(() => {
                typingEl.remove();
                const q = val.toLowerCase();
                if(q.includes('home')) {
                    appendMsg('Navigate back to core operations via the <a href="/home.html" style="color:var(--primary); font-weight:bold;">Home Terminal</a>.', false);
                } else if(q.includes('name of bikes') || q.includes('top best') || q.includes('best once')) {
                    appendMsg('The absolute pinnacle of our fleet includes the <a href="/product-detail.html?id=11" style="color:var(--primary);">Tesla CyberMoto</a>, <a href="/product-detail.html?id=28" style="color:var(--primary);">Apex DroneBike</a>, and the <a href="/product-detail.html?id=22" style="color:var(--primary);">Neural Glider</a>.', false);
                } else
                if(q.includes('price') || q.includes('cost') || q.includes('rate')) {
                    appendMsg('Pricing starts at &#8377;80,000 for combustion and scales to &#8377;18,50,000 for flagship EVs.', false);
                } else if(q.includes('ev') || q.includes('electric')) {
                    appendMsg('We host top-tier EV bikes like the Ather 450X, Ola S1 Pro, and the concept Tesla CyberMoto.', false);
                } else if(q.includes('best') || q.includes('recommend') || q.includes('top')) {
                    appendMsg('For raw speed, I recommend the Ultraviolette F77. For classic cruising, the Street Glide.', false);
                } else if (q.includes('hello') || q.includes('hi ') || q === 'hi' || q.includes('hey')) {
                    appendMsg('Hello! I am Voxa, your intelligent mobility AI. How can I assist you?', false);
                } else {
                    appendMsg('Acknowledged. My neural net is processing your parameters.', false);
                }
            }, 1500);
        };
        voxaSend.addEventListener('click', handleChat);
        voxaInput.addEventListener('keypress', (e) => { if(e.key === 'Enter') handleChat(); });
    }

    observeReveals(); // trigger observers
});

    // Footer Injection
    const globalFooter = document.createElement('footer');
    globalFooter.className = 'global-footer';
    globalFooter.innerHTML = `
      <div class="footer-content">
          <div class="footer-col" style="max-width:300px;">
              <h3 class="nav-brand" style="font-size:1.5rem; color:#fff;">Robo<span style="color:var(--primary);">Ride</span></h3>
              <p class="text-muted" style="margin-top:1rem; font-size:0.9rem;">Elevating global mobility networks with deeply integrated AI and ultra-aesthetic aerodynamic foundations.</p>
          </div>
          <div class="footer-col">
              <h3>Fast Links</h3>
              <ul>
                  <li><a href="/home.html">Home Terminal</a></li>
                  <li><a href="/products.html">Complete Catalog</a></li>
                  <li><a href="/ev-bikes.html">EV Lineup</a></li>
                  <li><a href="/normal-bikes.html">Combustion</a></li>
              </ul>
          </div>
          <div class="footer-col">
              <h3>Support</h3>
              <ul>
                  <li><a href="/about.html">About Vision</a></li>
                  <li><a href="/help.html">Help Center</a></li>
                  <li><a href="/chatbot.html">Voxa Assistant</a></li>
              </ul>
          </div>
      </div>
      <div class="footer-bottom">
          &copy; 2026 RoboRide Mobility Inc. Built for the future. By Sovoxazen Standards.
      </div>
    `;
    document.body.appendChild(globalFooter);

    // Hamburger Logic
    const burger = document.getElementById('hamburger');
    const navLayout = document.getElementById('nav-links');
    if (burger && navLayout) {
        burger.addEventListener('click', () => {
            navLayout.classList.toggle('nav-active');
            burger.classList.toggle('toggle');
        });
    }

    // Capture forced filters passed via window mapping (for dedicated pages)
    if(window.dedicatedFilter) {
        // Find filter container and trigger the click on the relevant button if it exists
        // Otherwise just override currentFilter logic.
        // The render block in main.js defines 'currentFilter'. Since we might be modifying it locally,
        // we will manually force it by modifying the currentFilter inside the function scope or click simulate
        setTimeout(() => {
           const btns = document.querySelectorAll('.category-btn');
           let btnFound = false;
           btns.forEach(b => {
              if(b.getAttribute('data-filter') === window.dedicatedFilter) {
                  b.click();
                  btnFound = true;
              }
           });
           // If no buttons exist (dedicated grid), we do a hard filter ourselves on the DOM nodes
           if(!btnFound) {
              const cards = document.querySelectorAll('.product-card');
              cards.forEach(card => {
                  let type = card.getAttribute('data-type');
                  if (type) type = type.toLowerCase();
                  
                  // Force strictly hide any non-matching card natively
                  if(window.dedicatedFilter === 'Normal Bikes' && type !== 'normal') {
                      card.style.display = 'none';
                      card.classList.remove('animate-fade-in');
                  }
                  if(window.dedicatedFilter === 'EV Bikes' && type !== 'ev bikes') {
                      card.style.display = 'none';
                      card.classList.remove('animate-fade-in');
                  }
                  if(window.dedicatedFilter === 'Robotic Bikes' && type !== 'robotic') {
                      card.style.display = 'none';
                      card.classList.remove('animate-fade-in');
                  }
              });
           }
        }, 100);
    }

window.addEventListener('DOMContentLoaded', () => {
    if (window.location.pathname.indexOf('product-detail.html') !== -1) {
        const urlParams = new URLSearchParams(window.location.search);
        const bikeId = parseInt(urlParams.get('id'));
        if (bikeId && bikesData) {
            const bike = bikesData.find(b => b.id === bikeId);
            if (bike) {
                const detName = document.getElementById('det-name');
                const detBrand = document.getElementById('det-brand');
                const detPrice = document.getElementById('det-price');
                const detRating = document.getElementById('det-rating');
                const mainImg = document.getElementById('mainImage');
                const thumb1 = document.getElementById('thumb-1');

                if (detName) detName.innerText = bike.name;
                if (detBrand) detBrand.innerText = bike.brand + ' • ' + bike.category;
                if (detPrice) detPrice.innerText = bike.price;
                if (detRating) detRating.innerHTML = '? ' + bike.rating + ' <span style="font-size:1rem; color:var(--text-muted); font-weight:400;">(Top Rated)</span>';
                if (mainImg) mainImg.style.backgroundImage = 'url(' + bike.img + ')';
                if (thumb1) thumb1.style.backgroundImage = 'url(' + bike.img + ')';
            }
        }
    }
});
